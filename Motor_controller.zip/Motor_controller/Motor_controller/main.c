/*
 * Motor_Controller_Using_Bluetooth.c
 *
 * Created: 11/5/2019 8:52:45 PM
 * Author : Rony
 */ 

/*
 * Home_Automation.c
 *
 * Created: 10/12/2019 6:21:41 PM
 * Author : Rony
 */ 

/*
 * 9600.c
 *
 * Created: 4/27/2019 10:23:50 PM
 * Author : Rony
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#define F_CPU 1000000UL;
#define forward 1
#define reverse 0
void initalizeUART(void);
void setup_timer(void);
volatile unsigned char uart_data;
volatile unsigned char temp_uart_data;
volatile uint16_t middle_value;
volatile unsigned char flag=reverse;
 

int main(void)
{
    /* Replace with your application code */
	setup_timer();
	initalizeUART();//9600,1 stop bit, no parity, 8 data bit
	
	DDRB =0xff;
	
	
    while (1) 
    {
		if(uart_data==255)
		{
			OCR1A=OCR1B=middle_value;
			_delay_ms(5000);	
		}
		else
		{
			
			if(flag==forward)
			{
				
				OCR1A=OCR1B=middle_value+uart_data;
				
			}
			else if (flag==reverse)
			{
				OCR1A=OCR1B=middle_value-uart_data;
				
			}
						
		}	
    }//end while
}// end main

void initalizeUART()
{
	// double speed operation ,U2X=1
	//BAUD RATE=9600
	uint16_t UBBRValue =12;
	//put the upper part of the baud number here( bits 8 to 11)
	UBRR0H =(unsigned char ) (UBBRValue>>8);
	// Put the remaining part of the baud number here
	UBRR0L =(unsigned char ) UBBRValue;
	UCSR0A |=(1<<U2X0)	;// double speed operation
	
	// Enable the receiver and Transmitter and receive interrupt
	UCSR0B |=(1<<RXEN0) | (1<<TXEN0) |(1<<RXCIE0);
	sei();//enable global interrupt
	// by default 1 stop bit
	//by default no parity
	UCSR0C |=(1<<UCSZ00)|(1<<UCSZ01);//8 bit
}

void setup_timer(void)
{
	//Fast PWM, 1us, ICR1 top, clear on compare match only by OCR1A
	TCCR1A	|=(1<<COM1A1) |(1<<COM1B0)|(1<<COM1B1)|(1<<WGM11);
	TCCR1B  |=(1<<WGM12) |(1<<WGM13) |(1<<CS10);

	ICR1=511;//511 us. As bluetooth  can send 8 bit (0-255) data so using 8 bit data both forward and reverse can be done.So 2*256=512 clock tic should be total period.We use 511 so that middle value can be 256.
	OCR1A =OCR1B=100;
	
	middle_value=(ICR1+1)/2;// because 1st value is zero
	
}

ISR(USART_RX_vect)
 {
	 
	while(!(UCSR0A & (1<<RXC0)));
	 temp_uart_data= UDR0;

	switch (temp_uart_data)
	{
	
	case 1:
	flag=forward;
	break;
	case 0:
	flag=reverse;
	break;
	default:
	uart_data=temp_uart_data;
	break;
	}

}

